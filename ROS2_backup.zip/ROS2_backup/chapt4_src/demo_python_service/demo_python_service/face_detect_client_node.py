import rclpy
from rclpy.node import Node
from my_interfaces.srv import FaceDetector
import face_recognition
import cv2
from ament_index_python.packages import get_package_share_directory 
import os
from cv_bridge import CvBridge
import time
from rcl_interfaces.srv import SetParameters
from rcl_interfaces.msg import Parameter


class FacedetecClientNode(Node):
    def __init__(self):
        super().__init__('face_detect_node')
        self.bridge = CvBridge()
        self.default_image_path = os.path.join(get_package_share_directory('demo_python_service'),'resource/text1.jpg')
        self.get_logger().info("人脸检测客户端服务启动")
        self.client = self.create_client(FaceDetector,'face_detect')
        self.image = cv2.imread(self.default_image_path)

    def call_set_parameters(self,parameters):
        update_param = self.create_client(SetParameters,'/face_detect_node/set_parameters')
        while update_param.wait_for_service(timeout_sec=1.0) is False:
            self.get_logger().info('等待参数更新服务端上线！')
        request = SetParameters.Request()
        request.parameters = parameters
        future = update_param.call_async()
        rclpy.spin_until_future_complete(self,future)
        response = future.result()
        return response


    def send_request(self):
        while self.client.wait_for_service(timeout_sec=1.0) is False:
            self.get_logger().info('等待服务端上线！')
        request = FaceDetector.Request()
        request.image = self.bridge.cv2_to_imgmsg(self.image)
        future = self.client.call_async(request)
        # rclpy.spin_until_future_complete(self,future)
        def result_callback(result_future):
            response = future.result()
            self.get_logger().info(f'接收到响应，共有{response.number}多少张人脸，耗时{response.use_time}s')
            self.show_response(response)
        future.add_done_callback(result_callback)
        

    def show_response(self,response):
        for i in range(response.number):
            top = response.top[i]
            right = response.right[i]
            bottom = response.bottom[i]
            left = response.left[i]
            cv2.rectangle(self.image,(left,top),(right,bottom),(255,0,0),4)
        cv2.imshow('Face Detecte Result',self.image)
        cv2.waitKey(0)



def main():
    rclpy.init()
    node = FacedetecClientNode()
    node.send_request()
    rclpy.spin(node)
    rclpy.shutdown

