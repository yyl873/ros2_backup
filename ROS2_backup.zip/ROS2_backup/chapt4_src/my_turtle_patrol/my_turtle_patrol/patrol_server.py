#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from my_interfaces.srv import Patrol
import math
import random

class TurtlePatrolServer(Node):
    def __init__(self):
        super().__init__('turtle_patrol_server')
        self.publisher = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.subscription = self.create_subscription(Pose, '/turtle1/pose', self.pose_callback, 10)
        self.srv = self.create_service(Patrol, '/patrol', self.patrol_callback)

        self.current_pose = None
        self.target_x = 5.5
        self.target_y = 5.5
        self.remaining_times = 0
        self.is_patrolling = False

        # 定时器：每 0.1 秒执行一次控制逻辑
        self.timer = self.create_timer(0.1, self.control_loop)
        self.get_logger().info("随机巡逻服务端已启动，等待请求...")

    def pose_callback(self, msg):
        self.current_pose = msg

    def patrol_callback(self, request, response):
        self.remaining_times = request.patrol_times
        self.is_patrolling = True
        self.pick_new_target()
        self.get_logger().info(f"收到巡逻请求：{request.patrol_times} 次")
        response.success = True
        return response

    def pick_new_target(self):
        # 随机生成目标点，范围 1.5 ~ 9.5，避免贴墙
        self.target_x = random.uniform(1.5, 9.5)
        self.target_y = random.uniform(1.5, 9.5)
        self.get_logger().info(f"新目标点: ({self.target_x:.2f}, {self.target_y:.2f})")

    def control_loop(self):
        if not self.is_patrolling or self.current_pose is None:
            return

        if self.remaining_times <= 0:
            self.stop_turtle()
            self.is_patrolling = False
            self.get_logger().info("巡逻任务完成！")
            return

        # 计算距离和角度差
        dx = self.target_x - self.current_pose.x
        dy = self.target_y - self.current_pose.y
        distance = math.sqrt(dx**2 + dy**2)

        # 到达目标点（容差 0.3）
        if distance < 0.3:
            self.remaining_times -= 1
            self.get_logger().info(f"到达目标，剩余巡逻次数: {self.remaining_times}")
            if self.remaining_times > 0:
                self.pick_new_target()
            return

        # 计算角度差并归一化到 [-pi, pi]
        target_angle = math.atan2(dy, dx)
        angle_diff = target_angle - self.current_pose.theta
        angle_diff = math.atan2(math.sin(angle_diff), math.cos(angle_diff))

        # P 控制器
        cmd = Twist()
        cmd.linear.x = min(1.5 * distance, 2.0)   # 限速，防止冲过头
        cmd.angular.z = 4.0 * angle_diff
        self.publisher.publish(cmd)

    def stop_turtle(self):
        self.publisher.publish(Twist())

def main(args=None):
    rclpy.init(args=args)
    node = TurtlePatrolServer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

