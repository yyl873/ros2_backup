#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from my_interfaces.srv import Patrol
import sys

class TurtlePatrolClient(Node):
    def __init__(self):
        super().__init__('turtle_patrol_client')
        # 创建服务客户端
        self.client = self.create_client(Patrol, '/patrol')
        # 等待服务端上线
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('等待巡逻服务端上线...')

    def send_request(self, times):
        request = Patrol.Request()
        request.patrol_times = times
        self.future = self.client.call_async(request)

def main(args=None):
    rclpy.init(args=args)
    client = TurtlePatrolClient()
    
    # 默认巡逻 3 次，也可以通过命令行参数指定，如：ros2 run my_turtle_patrol patrol_client 5
    times = 3
    if len(sys.argv) > 1:
        times = int(sys.argv[1])
        
    client.send_request(times)
    
    # 等待响应
    while rclpy.ok():
        rclpy.spin_once(client)
        if client.future.done():
            try:
                response = client.future.result()
                client.get_logger().info(f'服务端返回结果: 成功={response.success}')
            except Exception as e:
                client.get_logger().error(f'服务调用失败: {e}')
            break

    client.destroy_node()
    rclpy.shutdown()
