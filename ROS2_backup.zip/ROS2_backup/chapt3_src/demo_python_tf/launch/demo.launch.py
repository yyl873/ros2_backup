import launch
import launch_ros

def generate_launch_description():
    
    action_node_aaa = launch_ros.actions.Node(
        package='demo_python_tf',
        executable='dynamic_tf_broadcaster',
        output='log',
    ) 

    action_node_bbb = launch_ros.actions.Node(
        package='demo_python_tf',
        executable='static_tf_broadcaster',
        output='log',
      
    )
    action_node_ccc = launch_ros.actions.Node(
        package='demo_python_tf',
        executable='tf_listener',
        output='screen'
    )    
    return launch.LaunchDescription([
        action_node_aaa,
        action_node_bbb,
        action_node_ccc,
    ])
