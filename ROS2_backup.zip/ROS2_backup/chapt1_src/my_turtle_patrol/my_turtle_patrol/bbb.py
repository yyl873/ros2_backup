import rclpy
from rclpy.node import Node
from my_interfaces.srv import Patrol
import sys


class TurtlePatrolClient(Node):
    def __init__(self):
        super().__init__('turtle_patrol_client')
        self.client = self.create_client(Patrol,'/Patrol')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('等待巡逻服务端上线...')

    def send_request(self,times):
        request = Patrol.Request()
        request.patrol_times = times
        self.future = self.client.call_async(request)

def main(args=None):
    rclpy.init(args=args)
    
    # 1. 先创建节点，并声明一个参数 patrol_times，默认值 5
    client = TurtlePatrolClient()
    
    # 2. 从 ROS 2 参数系统里读取巡逻次数
    client.declare_parameter('patrol_times', 5)
    times = client.get_parameter('patrol_times').value

    client.send_request(times)

    while rclpy.ok():
        rclpy.spin_once(client)
        if client.future.done():
            try:
                response = client.future.result()
                client.get_logger().info(f'服务端返回结果: 成功={response.success}')
            except Exception as e:
                client.get_logger().error(f'服务调用失败: {e}')
            break

    client.destroy_node()
    rclpy.shutdown()