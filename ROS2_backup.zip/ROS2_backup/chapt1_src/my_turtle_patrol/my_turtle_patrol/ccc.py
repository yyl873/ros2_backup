import rclpy
from rclpy.node import Node
from  geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from my_interfaces.srv import Patrol
import math
import random


class TurtlePatrolServer(Node):
    def __init__(self):
        super().__init__('node1')
        self.get_logger().info(f'run!')

        self.publisher=self.create_publisher(Twist,'/turtle1/cmd_vel',10)
        self.subscription=self.create_subscription(Pose,'/turtle1/pose',self.pose_callback,10)
        self.service=self.create_service(Patrol,'/Patrol',self.patrol_callback)


        self.current_pose = None

        self.target_x = 5.5
        self.target_y = 5.5
        self.remaining_times = 0
        self.is_patrolling = False


        self.timer = self.create_timer(0.1,self.control_loop)
        self.get_logger().info("随机巡逻服务端已启动，等待请求...")



    def pose_callback(self,msg):  #位姿回调函数
        self.current_pose = msg






    def patrol_callback(self,request,response): #服务回调函数
        self.remaining_times = request.patrol_times
        self.is_patrolling = True
        self.pick_new_target()
        self.get_logger().info(f"收到巡逻请求：{request.patrol_times} 次")
        response.success = True

        return response






    def control_loop(self):
        if not self.is_patrolling or self.current_pose is None:

            return
        if self.remaining_times <= 0:
            self.stop_turtle()
            self.is_patrolling = False
            self.get_logger().info("巡逻任务完成！")
            return

        dx = self.target_x - self.current_pose.x
        dy = self.target_y - self.current_pose.y
        
        distance = math.sqrt(dx**2 + dy**2)

        if distance < 0.1:
            self.remaining_times -=1
            
            self.get_logger().info(f"到达目标，剩余巡逻次数: {self.remaining_times}")

            if self.remaining_times >0:
                self.pick_new_target()

            return


        target_angle = math.atan2(dy,dx)
        angle_diff = target_angle - self.current_pose.theta
        angle_diff = math.atan2(math.sin(angle_diff),math.cos(angle_diff))
        cmd = Twist()
        cmd.linear.x = min(1.5*distance,2.0)
        cmd.angular.z = 4.0*angle_diff
        self.publisher.publish(cmd)

    def pick_new_target(self): #巡逻点
        self.target_x = random.uniform(2.0,9.5)
        self.target_y = random.uniform(2.0,9.5)
        self.get_logger().info(f"新目标点: ({self.target_x:.2f}, {self.target_y:.2f})")







    def stop_turtle(self):
        self.publisher.publish(Twist())
    
    
def main():
    rclpy.init()
    node = TurtlePatrolServer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
        