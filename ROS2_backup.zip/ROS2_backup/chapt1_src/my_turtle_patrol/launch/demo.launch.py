import launch
import launch_ros

def generate_launch_description():
    action_declare_arg_background_g = launch.actions.DeclareLaunchArgument('launch_arg_bg',default_value="150")
    
    action_node_cturtlesim_node = launch_ros.actions.Node(
        package='turtlesim',
        executable='turtlesim_node',
        parameters=[{'background_g':launch.substitutions.LaunchConfiguration('launch_arg_bg',default="150")}],
        output='log'
    ) 

    action_node_bbb = launch_ros.actions.Node(
        package='my_turtle_patrol',
        executable='bbb',
        output='both',
        parameters=[{'patrol_times': 55}]
    )
    action_node_ccc = launch_ros.actions.Node(
        package='my_turtle_patrol',
        executable='ccc',
        output='log'
    )    
    return launch.LaunchDescription([
        action_declare_arg_background_g,
        action_node_cturtlesim_node,
        action_node_bbb,
        action_node_ccc,
    ])