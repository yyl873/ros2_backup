import os
import launch
import launch_ros
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # 1. 使用 os.path.join 安全拼接路径
    turtlesim_dir = get_package_share_directory('turtlesim')
    multisim_launch_path = os.path.join(turtlesim_dir, 'launch', 'multisim.launch.py')

    # 2. 引入外部的 launch 文件
    action_include_launch = launch.actions.IncludeLaunchDescription(
        launch.launch_description_sources.PythonLaunchDescriptionSource(
            multisim_launch_path
        )
    )

    # 3. 打印日志：显示我们要引入的路径
    action_log_info = launch.actions.LogInfo(msg=str(multisim_launch_path))

    # 4. 执行命令行进程，注意必须加 output='screen' 才能看到终端输出
    action_topic_list = launch.actions.ExecuteProcess(
        cmd=['rqt'],
        output='screen'
    )

    # 5. 使用 GroupAction 和 TimerAction 组合控制执行时序
    action_group = launch.actions.GroupAction([
        # 等待 2 秒后，启动引入的 multisim launch
        launch.actions.TimerAction(period=2.0, actions=[action_include_launch]),
        # 等待 4 秒后（给 multisim 留出启动时间），执行 topic list 查看话题
        launch.actions.TimerAction(period=4.0, actions=[action_topic_list]),
    ])

    return launch.LaunchDescription([
        action_log_info,
        action_group
    ])