from my_interfaces.srv._patrol import Patrol  # noqa: F401
