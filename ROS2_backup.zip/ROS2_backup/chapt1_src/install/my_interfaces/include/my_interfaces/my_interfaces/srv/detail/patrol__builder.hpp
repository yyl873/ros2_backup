// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from my_interfaces:srv/Patrol.idl
// generated code does not contain a copyright notice

#ifndef MY_INTERFACES__SRV__DETAIL__PATROL__BUILDER_HPP_
#define MY_INTERFACES__SRV__DETAIL__PATROL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "my_interfaces/srv/detail/patrol__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace my_interfaces
{

namespace srv
{

namespace builder
{

class Init_Patrol_Request_patrol_times
{
public:
  Init_Patrol_Request_patrol_times()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::my_interfaces::srv::Patrol_Request patrol_times(::my_interfaces::srv::Patrol_Request::_patrol_times_type arg)
  {
    msg_.patrol_times = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_interfaces::srv::Patrol_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_interfaces::srv::Patrol_Request>()
{
  return my_interfaces::srv::builder::Init_Patrol_Request_patrol_times();
}

}  // namespace my_interfaces


namespace my_interfaces
{

namespace srv
{

namespace builder
{

class Init_Patrol_Response_success
{
public:
  Init_Patrol_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::my_interfaces::srv::Patrol_Response success(::my_interfaces::srv::Patrol_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_interfaces::srv::Patrol_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_interfaces::srv::Patrol_Response>()
{
  return my_interfaces::srv::builder::Init_Patrol_Response_success();
}

}  // namespace my_interfaces

#endif  // MY_INTERFACES__SRV__DETAIL__PATROL__BUILDER_HPP_
