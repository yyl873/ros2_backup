# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(my_interfaces_IDL_FILES "srv/Patrol.idl")
set(my_interfaces_INTERFACE_FILES "srv/Patrol.srv;srv/Patrol_Request.msg;srv/Patrol_Response.msg")
