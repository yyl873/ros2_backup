import rclpy
from rclpy.node import Node

def main():
    rclpy.init() # 初始化工作分配资源
    node = Node('python_node') #定义这个节点名字
    node.get_logger().info('你好python节点！')
    node.get_logger().warn('你好python节点！') #警告级别的日至

    rclpy.spin(node) #运行节点，循环检测
    rclpy.shutdown()

if __name__=='__main__':
    main()