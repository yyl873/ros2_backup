class PersonNode:
    def __init__(self,name:str,age:int):
    print('bei diao yong')
    self.name = name 
    self.age = age

    def eat(self,eat:str):
        """
        eatfood
        """
        print(f"{self.name},{self.age}age,love eat{eat}")

def main():
    node = PersonNode('mother',40)
    node.eat('fash')
    
