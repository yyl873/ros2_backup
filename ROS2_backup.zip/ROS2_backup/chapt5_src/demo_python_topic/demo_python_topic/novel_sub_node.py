import espeakng
import rclpy
from rclpy.node import Node
from example_interfaces.msg import String
from queue import Queue
import threading
import time
import rclpy
from rclpy.node import Node

class NovelSubNode(Node):
    def __init__(self,node_name):
        super().__init__(node_name)
        self.get_logger().info(f'{node_name},run!')
        self.novels_queue = Queue()
        self.novel_subscriber=self.create_subscription(String,'novel',self.novel_callback,10)
        self.speaking = threading.Thread(target=self.speech)
        self.speaking.start()

    def novel_callback(self,msg):
        self.novels_queue.put(msg.data)

    def speech(self):
        speaker = espeakng.Speaker()
        speaker.voice = 'en'

        while rclpy.ok():
            if self.novels_queue.qsize()>0:
                text = self.novels_queue.get()
                self.get_logger().info(f'speak{text}')
                speaker.say(text)
                speaker.wait()
            else:

                time.sleep(1)

def main():
    rclpy.init()
    node = NovelSubNode('novel_sub')
    rclpy.spin(node)
    rclpy.shutdown()