import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
import math

class NovelPubNode(Node):
    def __init__(self):
        super().__init__('car1')
        self.get_logger().info(f'run!')
        self.aaa_a = self.create_publisher(Twist,'/turtle1/cmd_vel',10)
        self.bbb_b = self.create_subscription(Pose,'/turtle1/pose',self.callback,10)
    
        self.first_x = 5
        self.first_y = 7
        self.get_logger().info(f'闭环已经打通')

    def callback(self,msg):
        distance = math.sqrt((self.first_x-msg.x)**2 + (self.first_y-msg.y)**2)
        angle    = math.atan2(self.first_y-msg.y,self.first_x-msg.x)- msg.theta 
        angle    = math.atan2(math.sin(angle),math.cos(angle))

        cmd = Twist()
        cmd.linear.x = 0.5 * distance
        cmd.angular.z = 1.5 * angle

        if  distance<0.1:
            if self.first_x == 5.0 and self.first_y == 7.0:
                self.get_logger().info(f'已到达目标点位，准备前往下一个目标点')
                self.first_x = 1
                self.first_y = 1
            else: 
                cmd.linear.x=0.0
                cmd.angular.z=0.0
                self.get_logger().info(f'已到达目标点位')



        self.aaa_a.publish(cmd)
        
def main():
    rclpy.init()
    node = NovelPubNode()
    rclpy.spin(node)
    node.destroy_node()             
    rclpy.shutdown()