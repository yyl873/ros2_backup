import rclpy                            # 导入ROS 2的Python客户端库
from rclpy.node import Node             # 导入Node基类，自定义节点需继承它
from geometry_msgs.msg import Twist     # 导入Twist消息类型，用于发布线速度和角速度
from turtlesim.msg import Pose          # 导入海龟仿真器的Pose消息类型，包含位置和朝向
import math                             # 导入Python数学库，用于计算平方根、三角函数等

class TurtleClosedLoop(Node):           # 定义一个类，继承自ROS 2的Node基类
    def __init__(self):                 # 类的初始化方法（构造函数），实例化时自动执行
        super().__init__('turtle_closed_loop')  # 调用父类Node的初始化，将节点命名为'turtle_closed_loop'
        
        # 1. 创建发布者，用于发送速度指令
        # 向话题 '/turtle1/cmd_vel' 发布 Twist 消息，队列长度为10
        self.cmd_vel_pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        
        # 2. 创建订阅者，用于获取当前位置
        # 订阅话题 '/turtle1/pose'，收到消息时执行 self.pose_callback 回调函数，队列长度为10
        self.pose_sub = self.create_subscription(Pose, '/turtle1/pose', self.pose_callback, 10)
        
        # 3. 设定目标位置
        self.target_x = -8.0             # 目标坐标 X（海龟仿真器默认画布范围大约在0~11之间）
        self.target_y = 9.0             # 目标坐标 Y
        self.get_logger().info('闭环控制节点已启动')  # 在终端打印日志，提示节点已成功启动

    def pose_callback(self, msg):       # 回调函数，每当订阅到一次Pose消息，就会自动执行一次
        # 4. 收到位置信息后，计算与目标的距离和角度误差
        # 计算当前点到目标点的直线距离（欧几里得距离），即距离误差
        distance_error = math.sqrt((self.target_x - msg.x)**2 + (self.target_y - msg.y)**2)
        
        # 计算当前朝向与目标点方向之间的角度差（角度误差）
        # math.atan2 计算目标向量与X轴的夹角，减去当前朝向 msg.theta
        angle_error = math.atan2(self.target_y - msg.y, self.target_x - msg.x) - msg.theta
        
        # 角度归一化到 [-pi, pi] 区间
        # 因为角度差可能超过360度或小于-360度，用sin/cos转一圈再取atan2，保证误差在最短路径内
        angle_error = math.atan2(math.sin(angle_error), math.cos(angle_error))

        # 5. 根据误差计算速度指令（简单的比例控制 P-Control）
        cmd = Twist()                   # 创建一个Twist消息对象，用于存放即将发布的速度指令
        cmd.linear.x = 0.5 * distance_error  # 线速度与距离误差成正比：距离越远，前进越快
        cmd.angular.z = 6.0 * angle_error    # 角速度与角度误差成正比：角度偏差越大，转得越快

        # 6. 如果距离误差很小，就停止
        if distance_error < 0.1:        # 设置一个到达目标的容差阈值（0.1），防止在目标点附近来回震荡
            cmd.linear.x = 0.0          # 线速度设为0，停止前进
            cmd.angular.z = 0.0         # 角速度设为0，停止转向
            self.get_logger().info('已到达目标点')  # 打印提示信息

        self.cmd_vel_pub.publish(cmd)   # 将计算好的速度指令发布出去，控制乌龟运动

def main(args=None):                    # 程序主入口
    rclpy.init(args=args)               # 初始化 ROS 2 通信上下文
    node = TurtleClosedLoop()           # 实例化我们编写的节点对象（此时会自动执行__init__）
    rclpy.spin(node)                    # 让节点进入自旋状态，持续处理回调（等待并执行pose_callback）
    node.destroy_node()                 # 当节点退出（如按Ctrl+C）后，销毁节点，释放资源
    rclpy.shutdown()                    # 关闭 ROS 2 通信上下文