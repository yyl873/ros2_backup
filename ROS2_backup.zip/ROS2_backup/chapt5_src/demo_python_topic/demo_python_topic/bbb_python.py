import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
import math

class NovelPubNode(Node):
    def __init__(self):
        super().__init__('node1')
        self.get_logger().info(f'run!')
        self.aaa_b=self.create_publisher(Twist,'/turtle1/cmd_vel',10)
        self.bbb_a=self.create_subscription(Pose,'/turtle1/pose',self.callback,10)

        self.a_x = 5
        self.a_y = 5
        self.get_logger().info(f'闭环已经打通')

    def callback(self,msg):
        first1 = math.sqrt((self.a_x - msg.x)**2 + (self.a_y - msg.y)**2)
        first2 = math.atan2(self.a_y-msg.y,self.a_x-msg.x) - msg.theta
        first2 = math.atan2(math.sin(first2),math.cos(first2))

        abc = Twist()
        abc.linear.x = 1.5 * first1
        abc.angular.z = 1.5 * first2

        if first1<0.1:
            abc.linear.x = 0.0
            abc.angular.z = 0.0
            self.get_logger().info(f'已经到达')

        self.aaa_b.publish(abc)


def main():
    rclpy.init()
    node = NovelPubNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()