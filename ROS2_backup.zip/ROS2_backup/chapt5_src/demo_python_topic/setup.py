from setuptools import find_packages, setup

package_name = 'demo_python_topic'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='yang',
    maintainer_email='yang@todo.todo',
    description='TODO: Package description',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'novel_pub_node = demo_python_topic.novel_pub_node:main',
            'novel_sub_node = demo_python_topic.novel_sub_node:main',
            'demo_python = demo_python_topic.demo_python:main',
            'aaa_python = demo_python_topic.aaa_python:main',
            'bbb_python = demo_python_topic.bbb_python:main',


            


        ],
    },
)
